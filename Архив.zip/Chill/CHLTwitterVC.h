//
//  CHLTwitterVC.h
//  Chill
//
//  Created by Ivan Grachev on 7/17/15.
//  Copyright (c) 2015 Victor Shamanov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CHLTwitterVC : UITableViewController

@end
