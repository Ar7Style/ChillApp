//
//  CompleteViewController.h
//  Chill
//
//  Created by Михаил Луцкий on 09.01.15.
//  Copyright (c) 2015 Chill. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CompleteViewController : UIViewController

@end
