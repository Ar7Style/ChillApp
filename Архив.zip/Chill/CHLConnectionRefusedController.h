//
//  CHLConnectionRefusedController.h
//  Chill
//
//  Created by Tareyev Gregory on 09.03.15.
//  Copyright (c) 2015 Chill. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CHLConnectionRefusedController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *messageView;

@end
