//
//  CHLTutorialPageContentViewController.h
//  Chill
//
//  Created by Ivan Grachev on 15/02/15.
//  Copyright (c) 2015 Chill. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CHLTutorialPageContentViewController : UIViewController

@property NSUInteger pageIndex;
@property UIView *contentViewToPresent;

@end
