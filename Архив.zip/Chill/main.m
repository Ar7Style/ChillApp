//
//  main.m
//  Chill
//
//  Created by Виктор Шаманов on 5/7/14.
//  Copyright (c) 2014 Mikhail Loutskiy. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CHLAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CHLAppDelegate class]));
    }
}
