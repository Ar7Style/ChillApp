//
//  APPROVEDViewController.h
//  Chill
//
//  Created by Михаил Луцкий on 17.11.14.
//  Copyright (c) 2014 Chill. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface APPROVEDViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *contentView;
@property (readwrite) NSInteger friendUserID;



@end
