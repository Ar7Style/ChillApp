//
//  CHLFriendsListViewController.h
//  Chill
//
//  Created by Тареев Григорий & Виктор Шаманов on 5/7/14.
//  Copyright (c) 2014 Chill. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GAITrackedViewController.h"

@interface CHLFriendsListViewController : UITableViewController

@end
