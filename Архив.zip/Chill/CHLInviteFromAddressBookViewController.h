//
//  CHLInviteFromAddressBookViewController.h
//  Chill
//
//  Created by Tareyev Gregory on 05.08.15.
//  Copyright (c) 2015 Chlil. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CHLInviteFromAddressBookViewController : UIViewController

@end
