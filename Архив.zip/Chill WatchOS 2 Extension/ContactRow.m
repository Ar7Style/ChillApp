//
//  ContactRow.m
//  Chill
//
//  Created by Михаил Луцкий on 22.11.15.
//  Copyright © 2015 Chlil. All rights reserved.
//

#import "ContactRow.h"

@implementation ContactRow
-(void)setName:(NSString *)title {
    [_userName setText:title];
}
@end
