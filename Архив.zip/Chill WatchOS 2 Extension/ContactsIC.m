//
//  ContactsIC.m
//  Chill
//
//  Created by Михаил Луцкий on 22.11.15.
//  Copyright © 2015 Chlil. All rights reserved.
//

#import "ContactsIC.h"
#import "ContactRow.h"

@interface ContactsIC ()

@end

@implementation ContactsIC

- (void)awakeWithContext:(id)context {
    [super awakeWithContext:context];
    NSLog(@"Open ContactsIC");
    // Configure interface objects here.
}

- (void)willActivate {
    // This method is called when watch view controller is about to be visible to user
    [super willActivate];
}

- (void)didDeactivate {
    // This method is called when watch view controller is no longer visible
    [super didDeactivate];
}

@end



