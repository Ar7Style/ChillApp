//
//  AppDelegate.h
//  PKImagePickerDemo
//
//  Created by pavan krishnamurthy on 7/7/14.
//  Copyright (c) 2014 pavan krishnamurthy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
